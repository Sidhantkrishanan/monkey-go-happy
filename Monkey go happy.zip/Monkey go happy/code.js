var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["a10827ae-bf7e-459b-be24-2063517ad9d5","89076ad2-17ed-4cc2-a6b0-a2f2c7647f8b","948032ca-676c-4ae7-b0c8-fb7ac37bec7c","c9837a42-4004-4bdb-bd60-3a2523dc761a","77893e67-66a0-468e-9671-282d5d99325b","233b9f21-c867-4c8e-922b-891900d53a21","2baf8732-e625-4832-ba95-9896663e97c4","bac1eb28-eba6-4e2b-8701-96b3d21cf445","1b6a5bb5-7162-44bb-9d08-80c32668f7a0","97231181-fe40-460f-ba2f-dd406caf9faf","4be78d1f-811a-4238-b86d-36263ae3cbb5"],"propsByKey":{"a10827ae-bf7e-459b-be24-2063517ad9d5":{"name":"ground1","sourceUrl":null,"frameSize":{"x":1596,"y":26},"frameCount":1,"looping":true,"frameDelay":12,"version":"JzuUTKubgPEZCiyGxiBOfXY2DdqrV_VP","loadedFromSource":true,"saved":true,"sourceSize":{"x":1596,"y":26},"rootRelativePath":"assets/a10827ae-bf7e-459b-be24-2063517ad9d5.png"},"89076ad2-17ed-4cc2-a6b0-a2f2c7647f8b":{"name":"ground2","sourceUrl":"assets/v3/animations/_zVr-Ht4cJETV573GIhR_widaY8yD24II_c3xbDv5s4/89076ad2-17ed-4cc2-a6b0-a2f2c7647f8b.png","frameSize":{"x":2377,"y":12},"frameCount":1,"looping":true,"frameDelay":4,"version":"KByo_I3iM8PDVy34I53pxUVuUL9gyRyO","loadedFromSource":true,"saved":true,"sourceSize":{"x":2377,"y":12},"rootRelativePath":"assets/v3/animations/_zVr-Ht4cJETV573GIhR_widaY8yD24II_c3xbDv5s4/89076ad2-17ed-4cc2-a6b0-a2f2c7647f8b.png"},"948032ca-676c-4ae7-b0c8-fb7ac37bec7c":{"name":"cloud","sourceUrl":"assets/v3/animations/RMvIP5z9gbC5QVTMhtnVaJrbAK7UBB5ceCkXG470Jjc/948032ca-676c-4ae7-b0c8-fb7ac37bec7c.png","frameSize":{"x":92,"y":27},"frameCount":1,"looping":true,"frameDelay":4,"version":"y93E2F78vOkGqgiyW_HKaIOl2aK3eGmq","loadedFromSource":true,"saved":true,"sourceSize":{"x":92,"y":27},"rootRelativePath":"assets/v3/animations/RMvIP5z9gbC5QVTMhtnVaJrbAK7UBB5ceCkXG470Jjc/948032ca-676c-4ae7-b0c8-fb7ac37bec7c.png"},"c9837a42-4004-4bdb-bd60-3a2523dc761a":{"name":"bannana_1","sourceUrl":"assets/api/v1/animation-library/gamelab/ccpZZOVIGskbfrQGMrryQFkMKlec5.T5/category_food/bannana.png","frameSize":{"x":382,"y":310},"frameCount":1,"looping":true,"frameDelay":1,"version":"ccpZZOVIGskbfrQGMrryQFkMKlec5.T5","loadedFromSource":true,"saved":true,"sourceSize":{"x":382,"y":310},"rootRelativePath":"assets/api/v1/animation-library/gamelab/ccpZZOVIGskbfrQGMrryQFkMKlec5.T5/category_food/bannana.png"},"77893e67-66a0-468e-9671-282d5d99325b":{"name":"farm_land_1","sourceUrl":"assets/api/v1/animation-library/gamelab/8RkOLYC69Uhn.b7A1GaLNOBfPiC_hGvT/category_backgrounds/farm_land.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"8RkOLYC69Uhn.b7A1GaLNOBfPiC_hGvT","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/8RkOLYC69Uhn.b7A1GaLNOBfPiC_hGvT/category_backgrounds/farm_land.png"},"233b9f21-c867-4c8e-922b-891900d53a21":{"name":"obstacle1","sourceUrl":"assets/api/v1/animation-library/gamelab/.pLS.n.SMG0pvfUy0tHxDssjtYmDbSjs/category_environment/rock.png","frameSize":{"x":128,"y":128},"frameCount":1,"looping":true,"frameDelay":2,"version":".pLS.n.SMG0pvfUy0tHxDssjtYmDbSjs","loadedFromSource":true,"saved":true,"sourceSize":{"x":128,"y":128},"rootRelativePath":"assets/api/v1/animation-library/gamelab/.pLS.n.SMG0pvfUy0tHxDssjtYmDbSjs/category_environment/rock.png"},"2baf8732-e625-4832-ba95-9896663e97c4":{"name":"restart.png_1","sourceUrl":"assets/v3/animations/D5205h3yb13MKR5vCvcM5Z9xtxToAdFT8U0Ecly2KWI/2baf8732-e625-4832-ba95-9896663e97c4.png","frameSize":{"x":75,"y":64},"frameCount":1,"looping":true,"frameDelay":4,"version":"ApykXn_N3nFiRuf9xR6HYXyOzxfU_zxt","loadedFromSource":true,"saved":true,"sourceSize":{"x":75,"y":64},"rootRelativePath":"assets/v3/animations/D5205h3yb13MKR5vCvcM5Z9xtxToAdFT8U0Ecly2KWI/2baf8732-e625-4832-ba95-9896663e97c4.png"},"bac1eb28-eba6-4e2b-8701-96b3d21cf445":{"name":"gameOver.png_1","sourceUrl":"assets/v3/animations/D5205h3yb13MKR5vCvcM5Z9xtxToAdFT8U0Ecly2KWI/bac1eb28-eba6-4e2b-8701-96b3d21cf445.png","frameSize":{"x":381,"y":21},"frameCount":1,"looping":true,"frameDelay":4,"version":"dMzFT71A5HlE476NYruqQ29rmJNEp2_o","loadedFromSource":true,"saved":true,"sourceSize":{"x":381,"y":21},"rootRelativePath":"assets/v3/animations/D5205h3yb13MKR5vCvcM5Z9xtxToAdFT8U0Ecly2KWI/bac1eb28-eba6-4e2b-8701-96b3d21cf445.png"},"1b6a5bb5-7162-44bb-9d08-80c32668f7a0":{"name":"obstacle2","sourceUrl":"assets/api/v1/animation-library/gamelab/Rqcw2twZeR1jL7Eph0siUz6gidu380GN/category_environment/rock_moss.png","frameSize":{"x":128,"y":128},"frameCount":1,"looping":true,"frameDelay":2,"version":"Rqcw2twZeR1jL7Eph0siUz6gidu380GN","categories":["environment"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":128,"y":128},"rootRelativePath":"assets/api/v1/animation-library/gamelab/Rqcw2twZeR1jL7Eph0siUz6gidu380GN/category_environment/rock_moss.png"},"97231181-fe40-460f-ba2f-dd406caf9faf":{"name":"monkey","sourceUrl":null,"frameSize":{"x":479,"y":369},"frameCount":2,"looping":true,"frameDelay":12,"version":"ztf9CKHn9r95M_a0Za5MxMPSBLgRBeQP","loadedFromSource":true,"saved":true,"sourceSize":{"x":479,"y":738},"rootRelativePath":"assets/97231181-fe40-460f-ba2f-dd406caf9faf.png"},"4be78d1f-811a-4238-b86d-36263ae3cbb5":{"name":"monkey1","sourceUrl":null,"frameSize":{"x":479,"y":369},"frameCount":1,"looping":true,"frameDelay":12,"version":"L62S7mBpHaKEVRKOlXNkFZJKvzECnYgY","loadedFromSource":true,"saved":true,"sourceSize":{"x":479,"y":369},"rootRelativePath":"assets/4be78d1f-811a-4238-b86d-36263ae3cbb5.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var back=createSprite(200,200,20,20); 
back.setAnimation("farm_land_1");

//create a monkey sprite
var monkey = createSprite(200,170,20,50);
monkey.setAnimation("monkey");

//scale and position the monkey
monkey.scale = 0.4;
monkey.x = 50;

var score=0;

var obsGrp=createGroup();
var cloudsGrp=createGroup();
var crowGrp=createGroup();

//create a ground sprite
var ground = createSprite(200,300,400,20);
ground.setAnimation("ground2");
ground.x = ground.width /2;

var invisibleGround = createSprite(200,300,400,5);
invisibleGround.visible = true;

monkey.setCollider("circle",-20,0,100);
var END=0;
var PLAY=1;
var gameState=PLAY;

//generate some randome number here

var restart=createSprite(200,200,20,20);
restart.scale=0.5;
restart.setAnimation("restart.png_1");
restart.visible = false;

var gameOver=createSprite(200,170,20,20);
gameOver.scale=0.5;
gameOver.setAnimation("gameOver.png_1");
gameOver.visible = false;

var x=1;
function draw() {
  //set background to white
  background(180);
  
  if(gameState===PLAY)
  {
    
  if(World.frameCount % 5===0){
  score=score+1;
  } 
  
  ground.velocityX = -(10+score/100); 
    
    //console.log(monkey.y);
  
  if (ground.x < 0){
    ground.x = ground.width/2;
  }
  //jump when the space key is pressed
  if(keyDown("space") && monkey.y >= 359)
  {
    monkey.velocityY = -15 ;
    playSound("assets/jump.mp3");
  }
  
  //add gravity
  monkey.velocityY = monkey.velocityY + 0.8;
  
  spawnObstacles();
  
    if(score%500===0){
    x=2;
    }
  if(monkey.isTouching(obsGrp))
  {
    playSound("assets/die.mp3");
    gameState=END;
  }
  if(score%100===0&&score>0){
    playSound("assets/checkPoint.mp3");
  }
  gameOver.visible = false;
}
  else if(gameState===END)
  {
    ground.velocityX=0;
    monkey.setAnimation("monkey1");
    obsGrp.setVelocityXEach(0);
    obsGrp.setLifetimeEach(-1);
    monkey.velocityY=0;
    restart.visible = true;
    gameOver.visible = true;
    if(mousePressedOver(restart))
    {
    reset();
    }
  }
  monkey.collide(invisibleGround);
  drawSprites ();
  
  text(score,350,10);

} 
  function spawnObstacles() {
 if(World.frameCount % 70 === 0){
   var obstacles=createSprite(400,260,60,60);
   obstacles.setAnimation("obstacle"+randomNumber(1,2));
   obstacles.scale=0.7; 
   
   obstacles.lifetime=134;
   obstacles.setCollider("circle",-20,0,10);
   
   obstacles.velocityX=ground.velocityX;
   obsGrp.add(obstacles);
  }
}
   function reset(){
    gameState=PLAY; 
    obsGrp.destroyEach();
    cloudsGrp.destroyEach();
    crowGrp.destroyEach();
    restart.visible=false;
    monkey.setAnimation("monkey");
    score=0;
   }

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
